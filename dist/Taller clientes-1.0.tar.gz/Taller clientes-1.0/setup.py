#importamos herramienta para generar ejecutables del programa

from distutils.core import setup
#import py2exe

setup(name="Taller clientes",
      version="1.0",
      description="Aplicacion para la gestion de un taller",
      author="David Pazo",
      author_email="dpazolopez@danielcastelo.org",
      url="http://mundopython.org/proyecto-python/",
      license="GPL",
      scripts=["Login.py","Taller.py","Generarpdf.py","basedatos.dat","inicio.glade","Taller.glade"],
      console=["Login.py"]
)